package models

type FordleResponse struct {
	Board []string
	Words []string
}
